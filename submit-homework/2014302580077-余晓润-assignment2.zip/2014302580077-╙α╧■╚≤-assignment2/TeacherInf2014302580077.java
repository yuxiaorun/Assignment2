package jsouptest;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
public class TeacherInf2014302580077 {
    private Document tinf;  
	private String name;
	private String direction;
	private String inf;
	private String email;
	private String tel;
	
	public void getDoc(String url){
    	  try {
			tinf =Jsoup.connect(url).get(); 
		} catch (IOException e) {
			e.printStackTrace();
		}
      }
public void process(){
	 Element Name=tinf.getElementsByTag("h3").first();
	 	name=Name.text();                                                              //�ҵ�����
	 	Element infs=tinf.getElementsByTag("p").first();
	 	direction=infs.childNode(2).toString();                               //�ҵ��о�����
	 	inf=infs.childNode(0).toString();                                         //�ҵ����
	 	Pattern p=Pattern.compile("\\w+@\\w+\\.\\w+.\\w+");
	 	  String u=infs.text();                                                                           
	 	  Matcher m=p.matcher(u);
	 	m.find();
	 	email=m.group();                                                             //�ҵ������ʼ�
		Pattern p1=Pattern.compile("[0-9]{11}");                                                
	 	  Matcher m1=p1.matcher(u);
	 	  m1.find();
	 	 tel=m1.group();                                                                   //�ҵ��绰
}
public void output() throws IOException{
	File file=new File("information.txt");
	BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-16"));
	writer.write("������"+name);                          //�����ͷ
	writer.newLine();
	writer.write("��飺"+inf);
	writer.newLine();
	writer.write(direction);
	writer.newLine();
	writer.write("�绰��"+tel);
	writer.newLine();
	writer.write("���䣺"+email);
	writer.close();
}
	public static void main(String[] args) throws IOException {
		TeacherInf2014302580077 AXP=new TeacherInf2014302580077();
		AXP.getDoc("http://staff.whu.edu.cn/show.jsp?lang=cn&n=Ai Xin Ping");
		AXP.process();
        AXP.output();
	}

}
